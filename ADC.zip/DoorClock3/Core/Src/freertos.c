/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "queue.h"
#include "usart.h"
#include "string.h"
#include "OLED.h"
#include "adc.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
	HAL_StatusTypeDef HalState;
	uint16_t Ret;
	uint16_t StartAndGetOneResult()
	{
			//�?始转�?
			HAL_ADC_Start(&hadc1);
			//等待转换
			HalState = HAL_ADC_PollForConversion(&hadc1, 10);
			if(HalState == HAL_OK)
			{
					Ret = HAL_ADC_GetValue(&hadc1);
			}	
			else
			{
					Ret = 0;
			}	
			return Ret;
	}
	
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for LEDstart */
osThreadId_t LEDstartHandle;
const osThreadAttr_t LEDstart_attributes = {
  .name = "LEDstart",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for usartRx */
osThreadId_t usartRxHandle;
const osThreadAttr_t usartRx_attributes = {
  .name = "usartRx",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for OLEDshow */
osThreadId_t OLEDshowHandle;
const osThreadAttr_t OLEDshow_attributes = {
  .name = "OLEDshow",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for LightCheck */
osThreadId_t LightCheckHandle;
const osThreadAttr_t LightCheck_attributes = {
  .name = "LightCheck",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for usartRxMsgQueue */
osMessageQueueId_t usartRxMsgQueueHandle;
const osMessageQueueAttr_t usartRxMsgQueue_attributes = {
  .name = "usartRxMsgQueue"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void vTaskLEDstart(void *argument);
void vTaskusartRx(void *argument);
void vTaskOLEDshow(void *argument);
void vTaskLightCheck(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of usartRxMsgQueue */
  usartRxMsgQueueHandle = osMessageQueueNew (16, sizeof(uint16_t), &usartRxMsgQueue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of LEDstart */
  LEDstartHandle = osThreadNew(vTaskLEDstart, NULL, &LEDstart_attributes);

  /* creation of usartRx */
  usartRxHandle = osThreadNew(vTaskusartRx, NULL, &usartRx_attributes);

  /* creation of OLEDshow */
  OLEDshowHandle = osThreadNew(vTaskOLEDshow, NULL, &OLEDshow_attributes);

  /* creation of LightCheck */
  LightCheckHandle = osThreadNew(vTaskLightCheck, NULL, &LightCheck_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_vTaskLEDstart */
/**
  * @brief  Function implementing the LEDstart thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_vTaskLEDstart */
void vTaskLEDstart(void *argument)
{
  /* USER CODE BEGIN vTaskLEDstart */
  /* Infinite loop */
  for(;;)
  {
		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
    osDelay(100);
		HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);
    osDelay(100);		
		
  }
  /* USER CODE END vTaskLEDstart */
}

/* USER CODE BEGIN Header_vTaskusartRx */
/**
* @brief Function implementing the usartRx thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskusartRx */
void vTaskusartRx(void *argument)
{
  /* USER CODE BEGIN vTaskusartRx */
	
		USART_RxMsg_t rxMsg;
	
  /* Infinite loop */
  for(;;)
  {
//    	if(xQueueReceive(usartRxMsgQueue, &rxMsg, pdMS_TO_TICKS(100)) == pdPASS)
//			{
//					//保持我们原有的处理鿻�?
//					HAL_UART_Transmit(&huart1, (uint8_t*)"OK\r\n", 4 ,100);
//					HAL_UART_Transmit(&huart1, rxMsg.readyBuffer, rxMsg.dataLength, 100);
//				
//					//清空缓冲�? （保持原有操作）
//					memset(rxMsg.readyBuffer, 0, RXBUFFERSIZE);
//			}		
  }
  /* USER CODE END vTaskusartRx */
}

/* USER CODE BEGIN Header_vTaskOLEDshow */
/**
* @brief Function implementing the OLEDshow thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskOLEDshow */
void vTaskOLEDshow(void *argument)
{
  /* USER CODE BEGIN vTaskOLEDshow */
	OLED_Init();
	OLED_Clear();
	OLED_ShowString(1, 1, "ADValue:");
	OLED_ShowString(2, 1, "Voltage:0.00V");
	
  /* Infinite loop */
  for(;;)
  {
    osDelay(1);
  }
  /* USER CODE END vTaskOLEDshow */
}

/* USER CODE BEGIN Header_vTaskLightCheck */
/**
* @brief Function implementing the LightCheck thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskLightCheck */
void vTaskLightCheck(void *argument)
{
  /* USER CODE BEGIN vTaskLightCheck */
		uint16_t ADValue;
		float Voltage;
	
  /* Infinite loop */
  for(;;)
  {
		ADValue = StartAndGetOneResult();
		OLED_ShowNum(1, 9, ADValue, 4);
		Voltage = (float) ADValue / 4095 *3.3;
		OLED_ShowNum(2, 9, (uint32_t)Voltage, 1);
		OLED_ShowNum(2, 11, ((uint16_t)(Voltage * 100)) % 100, 2); //显示电压余数用的
    osDelay(100);
  }
  /* USER CODE END vTaskLightCheck */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

